--------------------
modExtra
--------------------
Author: Sergei Peleskov <info@s1temaker.ru>
--------------------

A start kit for MODx Revolution.

Include packages:
'Ace'
'AjaxForm'
'ClientConfig'
'controlErrorLog'
'FormIt'
'MIGX'
'pdoTools'
'pThumb'
'Resizer'
'TinyMCE'
'translit'
'Vapor'